<?php
global $landings_default_domain;
?>

<p>ООО "Профилактика и здоровье"</p>
<p>293011, Москва, ул. Космонавтов, д. 21, стр. 2, офис 15</p>
<p>ИНН 7717631521, КПП, 771702103, ОГРН 1127762613226</p>
<a href="#politika" onclick="window.open('policy_euro.php'); return false;" class="politika popup-with-move-anim">Политика конфинденциальности</a>

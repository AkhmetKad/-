<?php
global $landings_default_domain;
?>

<p>ООО "ОППОРТЬЮНИТИ"</p>
<p>199406, г.Санкт-Петербург, Малый пр. В.О. д. 64, к.1, стр 1</p>
<p>ИНН 7801353160 ОГРН 1187847102288</p>
<a href="#politika" onclick="window.open('/policy2.php'); return false;" class="politika popup-with-move-anim">Политика конфинденциальности</a>

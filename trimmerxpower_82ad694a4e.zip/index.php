<?php require('onepage.php') ?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>XPOWER Trimmer - Rasoio elettrico</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="img/favicon.png">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="css/normalize.min.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/flexboxgrid.min.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/skeleton.min.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/hamburgers.min.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/responsive.css" type="text/css" media="all">
    <meta property="og:type" content="article" />
    <meta property="og:title" content="Триммер XPower" />
    <meta property="og:description" content="Инновационный триммер XPower прекрасно подходит для ухода, поддержания и моделирования бороды, усов или бакенбардов или прически. Сверх-острые лезвия, тример работает на аккумуляторе, имеет мощный двигатель, в комплект входит 4 насадки. Ещё никогда бритьё не было на столько безопасным и простым!"
    />
    <meta property="og:url" content="" />

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

   
    <style>
        .ajax_loader {display: none;}
        select, input, button {outline: none;}
        .ajax_loader_block {text-align: center;}
    </style>


<!-- LT code insertion -->

<!-- /LT code insertion -->

</head>

<body>
    <div class="wrapper">
        <section id="navMenu" class="row col-xs-12 center-xs no-margin-padding">
            <div class="content row center-xs no-margin-padding">
                <div class="logo row col-md-8 col-sm-4 col-xs-12 start-xs middle-xs">
                    <img src="img/logo_2.png" alt>
                    <div class="mobile-menu hamburger hamburger hamburger--3dx-r" title="Mostra/Nascondi il men&ugrave;">
                        <div class="hamburger-box">
                            <div class="hamburger-inner"></div>
                        </div>
                    </div>
                    <ul class="menu">
                        <li><a href="#slider" class="scroll_to">Описание</a></li>
                        <li><a href="#big-g" class="scroll_to">Обзор</a></li>
                        <li><a href="#text-image-banner-3" class="scroll_to">Комплектация</a></li>
                        <li><a href="#order_frame" class="hide button navMenu_button scroll_to">Заказать</a></li>
                    </ul>
                </div>
                <div class="row col-md-4 col-sm-8 col-xs-12 end-xs middle-xs">
                    <ul class="menu">
                        <li><a href="#order_frame" class="button navMenu_button scroll_to">Заказать</a></li>
                    </ul>
                </div>
            </div>
        </section>
        <section id="header" class="row col-xs-12 center-xs pet-pattern-1">
            <div class="content row col-xs-12 center-xs no-margin-padding">
                <div class="logo-column row col-md-5 col-xs-12 center-xs middle-xs">
                    <div class="logo row col-xs-12 center-xs top-xs">
                        <img src="img/logo_1.png">
                    </div>
                    <div class="price row col-xs-12 center-xs middle-xs">
                        <span class="old oldproductsum"><?= $oldPriceHtml ?> <?= $currencyDisplayHtml ?></span>
                        <span class="new pulse productsum"><?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
                        <span class="discount">
<p><b>53%</b> скидка</p>
<img src="img/discount.png">
</span>
                    </div>
                    <div class="specs row col-xs-12 center-xs middle-xs">
                        <div class="spec row col-xs-12 start-xs middle-xs">
                            <div class="content row col-xs-12 start-xs middle-xs no-margin-padding">
                                <img src="img/icon.png">
                                <div class="text">
                                    <span>Остро</span> заточенные лезвия
                                </div>
                            </div>
                        </div>
                        <div class="spec row col-xs-12 start-xs middle-xs">
                            <div class="content row col-xs-12 start-xs middle-xs no-margin-padding">
                                <img src="img/icon.png">
                                <div class="text">
                                    <span>Мощный</span> и высокоскоростной двигатель <span>6000 об/мин</span>
                                </div>
                            </div>
                        </div>
                        <div class="spec row col-xs-12 start-xs middle-xs">
                            <div class="content row col-xs-12 start-xs middle-xs no-margin-padding">
                                <img src="img/icon.png">
                                <div class="text">
                                    <span>Более 120 минут</span> бесперебойной работы
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="watch row col-md-7 col-xs-12 end-md center-xs bottom-xs no-margin-padding">
                    <img src="img/header_man.png" class></div>
            </div>
        </section>
        <section id="only-text-banner" class="blackMesh">
            <div class="container row col-xs-12 center-xs middle-xs">
                <div class="row1">
                    <img src="img/logo_3.png" alt> - профессиональная бритва, которая острее, быстрее и эффективнее, чем все предыдущие поколения
                </div>
                <div class="lower row col-xs-12 center-xs middle-xs">
                    <div class="countdown_button row col-xs-12 center-xs middle-xs">
                        <div class="content row col-xs-12 center-xs middle-xs">
                            <div class="countdown row col-sm-6 col-xs-12 center-xs middle-xs">
                                <div id="time" class="time">
                                    <div class="timer__tx center">До повышение цены осталось:</div>
                                    <ul>
                                        <li>00
                                            <div class="podp">часов</div>
                                        </li>
                                        <li>37
                                            <div class="podp">минут</div>
                                        </li>
                                        <li>11
                                            <div class="podp">секунд</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="btn row col-sm-6 col-xs-12 center-xs middle-xs">
                                <a href="#order_frame" class="scroll_to" title="ORDINA ORA">
                                    <div class="mybutton_round">Заказать сейчас</div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="advise-banner" class="row col-xs-12 start-xs no-margin-padding">
            <div class="maxColumn content row center-xs no-margin no-padding">
                <div class="sx row col-md-6 col-xs-12 start-xs middle-xs">
                    <span class="surtitle">Профессиональная стрижка у вас дома</span>
                    <span class="title">Поможет сделать как простую, так и индивидуальную стрижку в домашних условиях</span>
                    <span class="subtitle">Бритва <span class="italic">xPower Trimmer</span> с инновационной технологией заточки лезвий Nano-Edge позволит вам начинать каждый день с абсолютно чистого и бережного бритья.</span>
                    <div class="bottom row col-xs-12 center-xs">
                        <div class="box row col-md-6 col-xs-12 center-xs">
                            <span class="title"><i class="icon icon-ok-circled"></i>Выбор длины среза</span>
                            <span class="description">Верхний подвижный нож подвигают близко к краю гребенки на расстояние до 0,05 мм, добиваясь бритвенного среза.</span>
                        </div>
                        <div class="box row col-md-6 col-xs-12 center-xs">
                            <span class="title"><i class="icon icon-ok-circled"></i>Дополнительные 4&nbsp;насадки</span>
                            <span class="description">Применяют для ухода за бородой, бакенбардами и усами. Насадки надежно крепятся на гребенке и не слетают во время стрижки.</span>
                        </div>
                        <div class="box row col-md-6 col-xs-12 center-xs">
                            <span class="title"><i class="icon icon-ok-circled"></i>Энергоэффективный аккумулятор</span>
                            <span class="description">Литиевая аккумуляторная батарея не теряет емкость, если триммер ставить на зарядку, не дожидаясь полной разрядки, не нуждается в тренировочных циклах «разряд — заряд».</span>
                        </div>
                        <div class="box row col-md-6 col-xs-12 center-xs">
                            <span class="title"><i class="icon icon-ok-circled"></i>Эргономика</span>
                            <span class="description">Сбалансированный черный корпус модели удобно ложится в руку. Работающий без вибрации со скоростью 6000 оборотов в минуту роторный мотор.</span>
                        </div>
                    </div>
                </div>
                <div class="dx row col-md-6 col-xs-12 center-xs middle-xs">
                    <img src="img/advise.jpg"></div>
            </div>
        </section>
        <section id="slider" class="slider_1">
            <div class="content row col-xs-12 no-margin no-padding">
                <div class="images col-md-6 col-xs-12 center-xs">
                    <div class="slider-carousel-1">
                        <div class="carousel-cell">
                            <img src="img/slide.jpg" alt></div>
                    </div>
                </div>
                <div class="text luxuryTexture row col-md-6 col-xs-12 center-xs middle-xs no-margin no-padding">
                    <div class="title start-xs">
                        <div class="innerTitle">
                            Экономия времени и денег на походах к парикмахеру
                        </div>
                        Благодаря разным насадкам вы сможете выбрать нужную длину волос, самостоятельно ухаживать за бородой и подравнивать причёску без визита в парикмахерскую – 4 сменные насадки вам в этом помогут.
                        <br><br> Остро заточенные лезвия без усилий создают точный срез длиной 1/10 мм. Нож T-Blade применяют для оформления контуров стрижки: линия окантовки в шейно-воротниковой зоне и за ушами, бритье бороды, усов, баков или подчистки
                        после машинки. Триммерами с Т-ножами выполняют узоры на волосах в стиле Hair Tattoo — стрижки-татуировки.
                        <br><br> Керамическое лезвие обеспечивает плавность хода и гарантирует превосходное качество стрижки.
                        <br><br> Триммер <span class="italic">xPower</span> — также настоящая находка для родителей, желающих, чтобы их дети выглядели аккуратными между стрижками.
                        <br><br>
                        <div class="cornerButton"><a href="#order_frame" class="scroll_to">Заказать со скидкой</a></div>
                    </div>
                </div>
            </div>
        </section>
        <section id="box-banner" class>
            <div class="content ">
                <div class="innerTitle">
                    Особый комфорт во время работы
                </div>
                <div class="subtitle">
                    Основные преимущества триммера <span class="italic">xPower</span>
                </div>
                <ul class="box-banner-carousel">
                    <li class="carousel-cell">
                        <div class="content row col-xs-12 center-xs">
                            <div class="image">
                                <img src="img/1.jpg"></div>
                            <div class="description row center-xs">
                                <div class="title row col-xs-12 middle-xs center-xs">
                                    <span>01</span> Литиевая батарея
                                </div>
                                <div class="text">
                                    Встроенный Li-Ion-аккумулятор без эффекта «химической памяти» работает до 120 мин непрерывно
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="carousel-cell is-selected">
                        <div class="content row col-xs-12 center-xs">
                            <div class="image">
                                <img src="img/2.jpg"></div>
                            <div class="description row center-xs">
                                <div class="title row col-xs-12 middle-xs center-xs">
                                    <span>02</span> Мощный двигатель
                                </div>
                                <div class="text">
                                    Высокоскоростной двигатель работает без вибраций со скоростью 6000 оборотов в минуту
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="carousel-cell">
                        <div class="content row col-xs-12 center-xs">
                            <div class="image">
                                <img src="img/3.jpg"></div>
                            <div class="description row center-xs   ">
                                <div class="title row col-xs-12 middle-xs center-xs">
                                    <span>03</span> Острые лезвия
                                </div>
                                <div class="text">
                                    Сделаны из твердой углеродистой стали с хромированной финишной отделкой для устойчивости к коррозии
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <div class="cornerButton"><a href="#order_frame" class="scroll_to">Заказать со скидкой</a></div>
            </div>
        </section>
        <section id="big-g" class>
            <div class="content row col-xs-12 center-xs">
                <div class="feature feature-s2 row col-xs-12 center-xs middle-xs">
                    <div class="left-text col-md-4 col-sm-6 end-md center-xs">
                        <div class="feature-item feature-item-c row col-xs-12 center-xs middle-xs">
                            <div class="text">
                                <h2 class="row end-md center-xs middle-xs">
                                    Стальные лезвия
                                </h2>
                                <p>Лезвия изготовлены из твердой углеродистой стали устойчивой к повреждениям.</p>
                            </div>
                            <img src="img/1.png">
                        </div>
                        <div class="feature-item feature-item-a row col-xs-12 center-xs middle-xs">
                            <div class="text">
                                <h2 class="row end-md center-xs middle-xs">
                                    Надежное крепление
                                </h2>
                                <p>Насадки надежно крепятся на гребенке и не слетают во время стрижки.</p>
                            </div>
                            <img src="img/2.png">
                        </div>
                        <div class="feature-item feature-item-a row col-xs-12 center-xs middle-xs">
                            <div class="text">
                                <h2 class="row end-md center-xs middle-xs">
                                    Одна кнопка ВКЛ / ВЫКЛ
                                </h2>
                                <p>Простота использования: одна кнопка для управления устройством.</p>
                            </div>
                            <img src="img/3.png">
                        </div>
                    </div>
                    <div class="center-text col-md-4 col-xs-12">
                        <div class="big-g-carousel feature-img">
                            <div class="carousel-cell">
                                <img class src="img/hand.png"></div>
                        </div>
                    </div>
                    <div class="right-text col-md-4 col-sm-6 start-md center-xs">
                        <div class="feature-item feature-item-e">
                            <img src="img/4.png">
                            <div class="text">
                                <h2 class="row start-md center-xs middle-xs">
                                    Высокоскоростной двигатель
                                </h2>
                                <p>Для стрижки любых волос независимо от структуры и густоты</p>
                            </div>
                        </div>
                        <div class="feature-item feature-item-g row col-xs-12 center-xs middle-xs">
                            <img src="img/5.png">
                            <div class="text">
                                <h2 class="row start-md center-xs middle-xs">
                                    4 насадки
                                </h2>
                                <p>Для ухода за бородой, бакенбардами и усами</p>
                            </div>
                        </div>
                        <div class="feature-item feature-item-a row col-xs-12 center-xs middle-xs">
                            <img src="img/6.png">
                            <div class="text">
                                <h2 class="row start-md center-xs middle-xs">
                                    USB зарядка
                                </h2>
                                <p>Можете брать его с собой куда угодно и зарядить в любой момент с помощью USB-кабеля.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="text-image-banner" class="redMeshAlpha">
            <div class="content row col-xs-12 center-xs middle-xs no-margin">
                <div class="image">
                    <img src="img/animation.gif"></div>
                <div class="text">
                    Сверх острые лезвия легко срезают даже самые длинные или самые густые волоски, не выдергивает и делает это равномерно.
                    <br><br> Доверьтесь многолетнему опыту xPower!
                </div>
                <img class="trimmer" src="img/icon_blade.png">
            </div>
        </section>
        <section id="text-image-banner-3" class>
            <div class="content container row col-xs-12 center-xs middle-xs">
                <div class="image">
                    <img src="img/packaging.jpg"></div>
                <div class="text">
                    <div class="innerTitle"><i class="icon icon-ok-circled"></i>Комплектация</div>
                    <ul>
                        <li>Машинка <span class="italic">xPower Trimmer</span></li>
                        <li>4 насадки гребни</li>
                        <li>USB кабель для зарядки</li>
                        <li>Щеточка для чистки лезвий</li>
                    </ul>
                    <br>
                    <div class="or_brd">
                        Осталось всего <u>4</u> триммеров со скидкой 53%! Заказывайте весь комплект всего за <span class="old_prc oldproductsum"></span> <b class="new_prc productsum"></b>
                    </div>
                    <br>
                    <div class="cornerButton" style="font-size: 15px;"><a href="#order_frame" class="scroll_to">Заказать со скидкой</a></div>
                </div>
            </div>
        </section>
        <section id="opinions_secureShopping_wrapper" class="lateralImageGray">
            <div id="opinions" class>
                <div class="container">
                    <h2 class="title row col-xs-12 center-xs">Отзывы наших покупателей</h2>
                    <p class="subtitle row col-xs-12 center-xs">говорят о качестве сами за себя</p>
                    <div class>
                        <div class="opinions-carousel feature-img">
                            <div class="carousel-cell">
                                <div class="facebook-box">
                                    <div class="content">
                                        <div class="row header">
                                            <div class="avatar">
                                                <img src="img/ava1.png" alt></div>
                                            <div class="name">
                                                <h5><a>Виктор Володин</a></h5>
                                                <span class="sub">г. Новосибирск</span>
                                            </div>
                                        </div>
                                        <div class="row text">
                                            Я, наверное, мечта любого барбера)) У меня бакенбарды, усы и длинная борода. При этом ещё и волосы очень густые и быстрорастущие. Я очень много денег трачу на поддержание всей этой красоты. Но даже потраченные деньги меня смущают не так, как потраченное
                                            на все эти поездки в барбер-шопы время. Поэтому купил себе этот триммер, чтобы работать самому, это оказалось вообще не сложно!
                                        </div>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-cell">
                                <div class="facebook-box">
                                    <div class="content">
                                        <div class="row header">
                                            <div class="avatar">
                                                <img src="img/ava2.png" alt></div>
                                            <div class="name">
                                                <h5><a>Солтан Боташев</a></h5>
                                                <span class="sub">г. Казань</span>
                                            </div>
                                        </div>
                                        <div class="row text">
                                            Не, им реально удобно работать, хорошая вещь! Не скользит ручка, держать удобно и волосы удаляются везде, не шутки!
                                        </div>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-cell">
                                <div class="facebook-box">
                                    <div class="content">
                                        <div class="row header">
                                            <div class="avatar">
                                                <img src="img/ava3.png" alt></div>
                                            <div class="name">
                                                <h5><a>Мага Темирзоев</a></h5>
                                                <span class="sub">г. Москва</span>
                                            </div>
                                        </div>
                                        <div class="row text">
                                            Классный триммер! Он от аккума работает, можно возить с собой куда хочешь, я беру его даже в дорогу, когда ездили на отдых. Лёгкий, места не занимает в сумке моей))
                                        </div>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-cell">
                                <div class="facebook-box">
                                    <div class="content">
                                        <div class="row header">
                                            <div class="avatar">
                                                <img src="img/ava4.png" alt></div>
                                            <div class="name">
                                                <h5><a>Олег Сидоров</a></h5>
                                                <span class="sub">г. Мёрленбах</span>
                                            </div>
                                        </div>
                                        <div class="row text">
                                            Отличный триммер, ставлю 10 из 10 за многофункциональность. Насадки мягкие, не раздражают кожу, пользоваться устройством легко и просто. Как по мне, это пока что лучший вариант и для стрижки, и для ухода за бородой и усами.
                                        </div>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="secureShopping" class="grayMesh_light">
            <div class="content container row col-xs-12 center-xs">
                <h1 class="title">Ваша покупка на 100% безопасна!</h1>
                <p class="subtitle">Заказывая на нашем сайте, вы приобретаете только качественную и оригинальную продукцию</p>
                <div class="list">
                    <ul>
                        <li class="row col-xs-12 middle-xs start-md center-xs">
                            <img src="img/lock.svg" alt>
                            <div class="opt-con">
                                <h4>Максимальная защита ваших персональных данных</h4>
                            </div>
                        </li>
                        <li class="row col-xs-12 middle-xs start-md center-xs">
                            <img src="img/delivery.svg" alt>
                            <div class="opt-con">
                                <h4>Быстрая доставка без предоплат!</h4>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <section id="order">
            <div class="content">
                <div id="countdown">
                    <div class="container">
                        <div class="content">
                            <div class="countdown">
                                <div id="time" class="time">
                                    <div class="timer__tx center">До повышение цены осталось:</div>
                                    <ul>
                                        <li>00
                                            <div class="podp">часов</div>
                                        </li>
                                        <li>00
                                            <div class="podp">минут</div>
                                        </li>
                                        <li>00
                                            <div class="podp">секунд</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="text">
                                <div class="or_brd white">
                                    Осталось всего <u>4</u> триммеров со скидкой 53%! Заказывайте весь комплект всего за <span class="old_prc oldproductsum"></span> <b class="new_prc productsum"></b>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div id="order_frame" class="center">
                        <div class="form-wrapper" id="buy-frame">

                            <form class="lt-form main-order-form" action="" method="post">


                                <center>
                                    <h3 class="title">Заполните форму</h3>
                                    <p>
                                        и наш менеджер перезвонит вам для уточнения деталей&nbsp;заказа
                                        <br> (звонок для вас абсолютно бесплатный)
                                    </p>
                                </center>
                                <div class="form-group">
                                    <label>Страна</label>
                                   <?= countrySelect() ?>    
                                </div>
                                <div class="form-group">
                                    <label>Введите ваше имя</label>
                                    <input type="text" name="name" class="form-control" placeholder="Ваше имя" required="required" value="">
                                </div>
                                <div class="form-group">
                                    <label>Введите ваш телефон</label>
                                    <input type="tel" name="phone" class="form-control" placeholder="Номер телефона" required="required" value="">
                                </div>
                                <center>

                                    <div class="reolader">
                                    <button class="btn btn-lg btn-warning new-sbm-btn mm_button" type="submit" >Заказать xPower Trimmer</button>
                                      
                                    </div>
                                </center>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div id="footer" class="no-margin">
            <div class="content container">
                <div class="footer-logo">
                    <img src="img/logo_2.png" alt></div>
                <div class="description">
                    <?= footer() ?>
                </div>
            </div>
        </div>
    </div>
    <link rel="stylesheet" href="css/fontello.css">
    <link rel="stylesheet" href="css/animate.min.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="preload" href="css/slick-theme.css">


    <script src="js/slick.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>


    </body>

</html>
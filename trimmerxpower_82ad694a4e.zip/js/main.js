$ = jQuery.noConflict();
$(document).ready(function() {
    buy_timer();
    $('.opinions-carousel').slick({
        centerMode: true,
        centerPadding: '250px',
        slidesToShow: 1,
        arrows: false,
        dots: true,
        adaptiveHeight: true,
        responsive: [{
            breakpoint: 1024,
            settings: {
                centerMode: false,
                dots: true
            }
        }]
    });
    $('.box-banner-carousel').slick({
        adaptiveHeight: true,
        dots: false,
        arrows: false,
        slidesToShow: 3,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: true
            }
        }]
    });
    $("#navMenu .mobile-menu").click(function() {
        if (!$("#navMenu ul.menu li").is(":visible")) {
            $("#navMenu .mobile-menu").addClass("is-active");
            $("#navMenu").addClass("open");
            $("#navMenu ul.menu li").slideDown("fast");
        } else {
            $("#navMenu ul.menu li").slideUp("fast", function() {
                $("#navMenu ul.menu li").removeAttr("style");
                $("#navMenu .mobile-menu").removeClass("is-active");
                $("#navMenu").removeClass("open");
            });
        }
    });
    $(document).on('click', '.scroll_to', function(event) {
        event.preventDefault();
        if (event.target.closest('#navMenu')) {
            $("#navMenu ul.menu li").slideUp("fast", function() {
                $("#navMenu ul.menu li").removeAttr("style");
                $("#navMenu .mobile-menu").removeClass("is-active");
                $("#navMenu").removeClass("open");
            });
        }
        var jump = $(this).attr('href');
        var new_position = $(jump).offset();
        $('html, body').stop().animate({
            scrollTop: new_position.top
        }, 500);
    });
});
var hour_s = '00';
var minutes_s = 59;
var seconds_s = 59;

function buy_timer() {
    if (!(minutes_s == '00' && seconds_s == '00')) {
        seconds_s--;
        if (seconds_s == -01) {
            seconds_s = 59;
            minutes_s = minutes_s - 1;
        } else minutes_s = minutes_s;
        if (seconds_s <= 9) seconds_s = "0" + seconds_s;
        minutes_sh = minutes_s;
        if (minutes_s < 10) minutes_sh = '0' + minutes_s;
        $('#time ul').html("<li>" + hour_s + "<div class='podp'>часов</div>" + "</li><li>" + minutes_sh + "<div class='podp'>минут</div>" + "</li><li>" + seconds_s + "<div class='podp'>секунд</div>" + "</li>");
        setTimeout("buy_timer()", 1000);
    } else {
        $(window).scrollTop($('#order_frame').offset().top);
    }
}
document.addEventListener('DOMContentLoaded', function() {
    var daysBlocks = Array.from(document.querySelectorAll('.date'));
    daysBlocks.forEach(function(block) {
        var daysShift = block.dataset.days || 0;
        var nowDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000 * daysShift).toLocaleDateString();
        block.innerText = nowDate;
    });
});
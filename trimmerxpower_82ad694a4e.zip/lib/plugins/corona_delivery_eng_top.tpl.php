<?php
global $shared_path;
?>
<link href="shared/plugins/corona_delivery_eng_top/virus.css" rel="stylesheet"/>
<script type="text/javascript" src="shared/plugins/corona_delivery_eng_top/virus.js"></script>
<div class="cc_widget">
    <div class="covid19-widget opened">
        <div class="covid19-widget__name covid19-widget__cell">
            COVID-19
        </div>
        <div class="covid19-widget__text covid19-widget__cell">
            Dont worry! We have taken all the measures so the safety of our customers can be guaranteed, our couriers
            change their gloves and masks every 2 hours
        </div>
        <div class="covid19-widget__btn opened">
            <img
                    src="shared/plugins/corona_delivery_eng_top/virus-arr.png"
                    alt="">
        </div>
    </div>
</div>
    
